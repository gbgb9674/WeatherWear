package com.example.weatherwear;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter_Fit extends RecyclerView.Adapter<Adapter_Fit.FitViewHolder> {
    private final List<Fit> fitList;
    public int selectedPos = RecyclerView.NO_POSITION;

    public Adapter_Fit(List<Fit> fitList) {
        this.fitList = fitList;
    }

    @NonNull
    @Override
    public Adapter_Fit.FitViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cont_fit, parent, false);
        return new Adapter_Fit.FitViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter_Fit.FitViewHolder holder, int position) {
        // Set the selected state
        holder.itemView.setSelected(selectedPos == position);
        // Set the views
        Fit fitData = fitList.get(position);
        holder.fitName.setText(fitData.getFitName());
        holder.fitImage.setImageResource(fitData.getFitImage());
        // If clicked, set to selected
        holder.itemView.setOnClickListener(view -> {
            notifyItemChanged(selectedPos);
            selectedPos = holder.getLayoutPosition();
            notifyItemChanged(selectedPos);
        });
    }

    @Override
    public int getItemCount() {
        return fitList.size();
    }

    // Implement getItem method to retrieve Fit object at a given position
    public Fit getItem(int position) {
        if (position < 0 || position >= fitList.size()) {
            return null; // Return null for invalid positions
        }
        return fitList.get(position);
    }

    public static class FitViewHolder extends RecyclerView.ViewHolder {
        TextView fitName;
        ImageView fitImage;

        public FitViewHolder(@NonNull View itemView) {
            super(itemView);
            fitName = itemView.findViewById(R.id.tv_fit_name);
            fitImage = itemView.findViewById(R.id.im_fit_cont);
        }
    }
}