package com.example.weatherwear;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter_WeatherHour  extends RecyclerView.Adapter<Adapter_WeatherHour.WeatherViewHolder> {
    private final List<WeatherHour> weatherDataList;

    public Adapter_WeatherHour(List<WeatherHour> weatherDataList) {
        this.weatherDataList = weatherDataList;
    }

    @NonNull
    @Override
    public WeatherViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cont_weather_hour, parent, false);
        return new WeatherViewHolder(view);
    }

    @SuppressLint("DefaultLocale")
    @Override
    public void onBindViewHolder(@NonNull WeatherViewHolder holder, int position) {
        WeatherHour weatherData = weatherDataList.get(position);
        holder.time.setText(weatherData.getTime());
        holder.temperature.setText(String.format("%.0f °C", weatherData.getTemperature()));
        WeatherService.loadWeatherIconImage(holder.itemView.getContext(), weatherData.getPicture(), holder.imageView);
    }

    @Override
    public int getItemCount() {
        return weatherDataList.size();
    }

    public static class WeatherViewHolder extends RecyclerView.ViewHolder {
        TextView time;
        TextView temperature;
        ImageView imageView;

        public WeatherViewHolder(@NonNull View itemView) {
            super(itemView);
            time = itemView.findViewById(R.id.tv_time_h);
            temperature = itemView.findViewById(R.id.tv_temp_h);
            imageView = itemView.findViewById(R.id.im_weather_h);
        }
    }
}
