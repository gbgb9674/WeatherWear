package com.example.weatherwear;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class DataBase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeatherWearBase.db";
    // TABLE 1
    private static final String TABLE_NAME1 = "FitCategories";
    private static final String CTG_ID = "CTGID";                   // Integer, auto increment
    private static final String CTG_DESCRIPTION = "CTGDES";         // String
    private static final String CTG_IMAGE_RES = "CTGRES";           // Integer
    private static final String CTG_TEMP_MIN = "CTGTMIN";            // Integer
    private static final String CTG_TEMP_MAX = "CTGTMAX";            // Integer

    // TABLE 2
    private static final String TABLE_NAME2 = "UpperFitsLog";
    private static final String UP_CTG_ID = "UPCTG";               // Integer
    private static final String UP_TEMP = "UPT";                   // Integer
    private static final String UP_TIMESTAMP = "UPTM";             // Long

    // TABLE 3
    private static final String TABLE_NAME3 = "BottomFitsLog";
    private static final String BOT_CTG_ID = "BOTCTG";              // Integer
    private static final String BOT_TEMP = "BOTT";                  // Integer
    private static final String BOT_TIMESTAMP = "BOTTM";            // Long

    public DataBase(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME1 + " (" + CTG_ID + " INTEGER, " + CTG_DESCRIPTION + " TEXT, " + CTG_IMAGE_RES + " INTEGER, " + CTG_TEMP_MIN + " INTEGER, " + CTG_TEMP_MAX + " INTEGER)");
        db.execSQL("CREATE TABLE " + TABLE_NAME2 + " (" + UP_CTG_ID + " INTEGER, " + UP_TEMP + " INTEGER, " + UP_TIMESTAMP + " LONG)");
        db.execSQL("CREATE TABLE " + TABLE_NAME3 + " (" + BOT_CTG_ID + " INTEGER, " + BOT_TEMP + " INTEGER, " + BOT_TIMESTAMP + " LONG)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME1);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME2);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME3);
        onCreate(db);
    }

    // FIT CATEGORIES
    public boolean dbCategories_addOne(Fit fit) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(CTG_ID, fit.getCategoryId());
        contentValues.put(CTG_DESCRIPTION, fit.getFitName());
        contentValues.put(CTG_IMAGE_RES, fit.getFitImage());
        contentValues.put(CTG_TEMP_MIN, fit.getMinTemp());
        contentValues.put(CTG_TEMP_MAX, fit.getMaxTemp());
        long result = db.insert(TABLE_NAME1, null, contentValues);
        return result != -1;  // if result == -1 data is not inserted
    }

    public List<Fit> dbCategories_read() {
        // 1 - upper fits, 2 - bottom fits
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME1 + " ORDER BY " + CTG_ID, null);
        // Initialize the list
        List<Fit> allData = new ArrayList<>();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0); // CTG_ID
            String description = cursor.getString(1); // CTG_DESCRIPTION
            int image = cursor.getInt(2); // CTG_IMAGE_RES
            int minTemp = cursor.getInt(3); // CTG_MIN_TEMP
            int maxTemp = cursor.getInt(4); // CTG_MAX_TEMP
            // Add to list
            allData.add(new Fit(id, description, image, minTemp, maxTemp));
        }
        cursor.close(); // Close the cursor when done
        return allData;
    }

    public void dbCategories_changeTemp(int ctgId1, int ctgId2, int newTemp) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("UPDATE " + TABLE_NAME1 + " SET " + CTG_TEMP_MIN + " = " + newTemp + " WHERE " + CTG_ID + " = " + ctgId1, null);
        cursor.moveToFirst();
        cursor.close(); // cursor needs to move to the result (and get closed) for the query to succeed
        cursor = db.rawQuery("UPDATE " + TABLE_NAME1 + " SET " + CTG_TEMP_MAX + " = " + newTemp + " WHERE " + CTG_ID + " = " + ctgId2, null);
        cursor.moveToFirst();
        cursor.close();
    }

    // UPPER FITS LOG
    public boolean dbUp_addOne(int upCtgId, int upTemp, long upTimestamp) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(UP_CTG_ID, upCtgId);
        contentValues.put(UP_TEMP, upTemp);
        contentValues.put(UP_TIMESTAMP, upTimestamp);
        long result = db.insert(TABLE_NAME2, null, contentValues);
        return result != -1;  // if result == -1 data is not inserted
    }

    public List<List<Integer>> dbUp_read() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME2, null);
        List<List<Integer>> allData = new ArrayList<>();
        while (cursor.moveToNext()) {
            List<Integer> rowData = new ArrayList<>();
            rowData.add(cursor.getInt(0)); // UP_CTG_ID
            rowData.add(cursor.getInt(1)); // UP_TEMP
            rowData.add(cursor.getInt(2)); // UP_TIMESTAMP
            allData.add(rowData);
        }
        cursor.close();
        return allData;
    }

    public List<FitCtgLog> dbUp_readAndArrange(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME2, null);
        Map<Integer, FitCtgLog> allData = new HashMap<>();
        while (cursor.moveToNext()) {
            int categoryId = cursor.getInt(0); // UP_CTG_ID
            int temperature = cursor.getInt(1); // UP_TEMP
            // If the category already exists in the map, add the temperature to its list
            // otherwise, create a new FitCtgLog and add it to the map
            if (allData.containsKey(categoryId)){
                Objects.requireNonNull(allData.get(categoryId)).getLoggedTemps().add(temperature);
            } else {
                List<Integer> temps = new ArrayList<>();
                temps.add(temperature);
                allData.put(categoryId, new FitCtgLog(categoryId, temps));
            }
        }
        cursor.close();
        // Convert the map values to a list and return
        return new ArrayList<>(allData.values());
    }


    // BOTTOM FITS LOG
    public boolean dbBot_addOne(int botCtgId, int botTemp, long botTimestamp) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(BOT_CTG_ID, botCtgId);
        contentValues.put(BOT_TEMP, botTemp);
        contentValues.put(BOT_TIMESTAMP, botTimestamp);
        long result = db.insert(TABLE_NAME3, null, contentValues);
        return result != -1;  // if result == -1 data is not inserted
    }

    public List<List<Integer>> dbBot_read() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME3, null);
        List<List<Integer>> allData = new ArrayList<>();
        while (cursor.moveToNext()) {
            List<Integer> rowData = new ArrayList<>();
            rowData.add(cursor.getInt(0)); // BOT_CTG_ID
            rowData.add(cursor.getInt(1)); // BOT_TEMP
            rowData.add(cursor.getInt(2)); // BOT_TIMESTAMP
            allData.add(rowData);
        }
        cursor.close();
        return allData;
    }

    public List<FitCtgLog> dbBot_readAndArrange(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM "+TABLE_NAME3, null);
        Map<Integer, FitCtgLog> allData = new HashMap<>();
        while (cursor.moveToNext()) {
            int categoryId = cursor.getInt(0); // UP_CTG_ID
            int temperature = cursor.getInt(1); // UP_TEMP
            // If the category already exists in the map, add the temperature to its list
            // otherwise, create a new FitCtgLog and add it to the map
            if (allData.containsKey(categoryId)){
                Objects.requireNonNull(allData.get(categoryId)).getLoggedTemps().add(temperature);
            } else {
                List<Integer> temps = new ArrayList<>();
                temps.add(temperature);
                allData.put(categoryId, new FitCtgLog(categoryId, temps));
            }
        }
        cursor.close();
        // Convert the map values to a list and return
        return new ArrayList<>(allData.values());
    }

    public void dbCategories_deleteAll() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME1, null, null);
    }

    public void dbUp_deleteAll() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME2, null, null);
    }

    public void dbBot_deleteAll() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME3, null, null);
    }

    public void db_deleteAll(){
        dbCategories_deleteAll();
        dbUp_deleteAll();
        dbBot_deleteAll();
    }

    public void db_deleteUserLogs(){
        dbUp_deleteAll();
        dbBot_deleteAll();
    }
}