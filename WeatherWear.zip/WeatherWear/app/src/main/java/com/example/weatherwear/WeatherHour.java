package com.example.weatherwear;

import androidx.annotation.NonNull;

public class WeatherHour {
    private final String time;
    private final float temperature;
    private final String picture;

    // constructor
    public WeatherHour(String time, float temperature, String picture) {
        this.time = time;
        this.temperature = temperature;
        this.picture = picture;
    }

    // getters and setters
    public String getTime() {
        return time;
    }

    public float getTemperature() {
        return temperature;
    }

    public String getPicture() {
        return picture;
    }

    @NonNull
    @Override
    public String toString() {
        return "WeatherHour{" +
                "time='" + time + '\'' +
                ", temperature=" + temperature +
                ", picture='" + picture + '\'' +
                '}';
    }
}