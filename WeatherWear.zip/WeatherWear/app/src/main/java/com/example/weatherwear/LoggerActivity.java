package com.example.weatherwear;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;
import java.util.Objects;

public class LoggerActivity extends AppCompatActivity {
    private final int dT = 1;
    // Views
    private EditText dateEdt;
    private EditText timeEdt;

    DataBase dataBase;

    private String convertToDate(int day, int month, int year) {
        StringBuilder text = new StringBuilder();
        if (day < 10)
            text.append("0");
        text.append(day).append(".");
        if (month < 10)
            text.append("0");
        text.append(month + 1).append(".").append(year);
        return text.toString();
    }

    private String convertToTime(int hour, int minute) {
        StringBuilder text = new StringBuilder();
        if (hour < 10)
            text.append("0");
        text.append(hour).append(":");
        if (minute < 10)
            text.append("0");
        text.append(minute);
        return text.toString();
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logger);

        // Find views
        dateEdt = findViewById(R.id.et_date);
        timeEdt = findViewById(R.id.et_time);
        Button btnLogSave = findViewById(R.id.btn_log_save);
        Button btnLogCancel = findViewById(R.id.btn_log_cancel);

        final Calendar calendar = Calendar.getInstance();
        int y = calendar.get(Calendar.YEAR);
        int m = calendar.get(Calendar.MONTH);
        int d = calendar.get(Calendar.DAY_OF_MONTH);
        int h = calendar.get(Calendar.HOUR_OF_DAY);
        int min = calendar.get(Calendar.MINUTE);

        // setting current date edit text.
        dateEdt.setText(convertToDate(d, m, y));
        timeEdt.setText(convertToTime(h, min));

        // Date picker
        dateEdt.setOnClickListener(view -> {
            // the instance of our calendar
            final Calendar customCalendar = Calendar.getInstance();

            // get day, month and year
            int customYear = customCalendar.get(Calendar.YEAR);
            int customMonth = customCalendar.get(Calendar.MONTH);
            int customDay = customCalendar.get(Calendar.DAY_OF_MONTH);

            // creating a variable for date picker dialog
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                // passing context
                LoggerActivity.this, (loggerView, year, month, day) -> {
                    // setting date to edit text
                    dateEdt.setText(convertToDate(day, month, year));
                },
                // passing the year, month and day for a date in our date picker
                customYear, customMonth, customDay);
            // display date picker dialog
            datePickerDialog.show();
        });

        // Time picker
        timeEdt.setOnClickListener(view -> {
            Calendar currentTime = Calendar.getInstance();
            int customHour = currentTime.get(Calendar.HOUR_OF_DAY);
            int customMinute = currentTime.get(Calendar.MINUTE);
            TimePickerDialog timePickerDialog = new TimePickerDialog(LoggerActivity.this,
                    (timePicker, hour, minute) -> timeEdt.setText(convertToTime(hour, minute)),
                    customHour, customMinute, true); // 24 hour time
            timePickerDialog.setTitle("Select Time");
            timePickerDialog.show();
        });

        // Get Fits from database
        dataBase = new DataBase(this);
        List<Fit> fits = dataBase.dbCategories_read();

        List<Fit> upperFits = new ArrayList<>();
        List<Fit> bottomFits = new ArrayList<>();
        // Separate the fits into upper and bottom fits
        for (Fit fit : fits) {
            int id = fit.getCategoryId();
            if (id >= 100 && id < 200) {
                upperFits.add(fit);
            } else if (id >= 200 && id < 300) {
                bottomFits.add(fit);
            }
        }

        // Fit chooser - Recycler View
        RecyclerView upperRecycler = findViewById(R.id.rv_fit_upper);
        upperRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        RecyclerView bottomRecycler = findViewById(R.id.rv_fit_bottom);
        bottomRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        Adapter_Fit fitAdapterUpper = new Adapter_Fit(upperFits);
        upperRecycler.setAdapter(fitAdapterUpper);
        Adapter_Fit fitAdapterBottom = new Adapter_Fit(bottomFits);
        bottomRecycler.setAdapter(fitAdapterBottom);

        // Button to log and save
        btnLogSave.setOnClickListener(view -> {

            String dateString = String.valueOf(dateEdt.getText());
            String timeString = String.valueOf(timeEdt.getText());
            int posUp = fitAdapterUpper.selectedPos;
            int posBot = fitAdapterBottom.selectedPos;

            Log.d("loggerSave", "date: " + dateString + ", time:" + timeString);
            Log.d("loggerSave", "posUpper: " + posUp + ", posBottom: " + posBot);

            if (posUp == -1 || posBot == -1) {
                // no fit chosen, do not save
                Toast.makeText(LoggerActivity.this, "Please choose fit!", Toast.LENGTH_LONG).show();
            }
            else {
                // long dt = 0;
                int day = 0;
                int month = 0;
                int year = 0;

                // Combine date and time into one string
                String dateTimeStr = dateString + " " + timeString;

                // Convert time and date
                try {
                    // Create a SimpleDateFormat object with the desired format
                    @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm");
                    // Parse the string into a Date object
                    Date date = sdf.parse(dateTimeStr);

                    // Get the day and month as integers
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(Objects.requireNonNull(date));
                    day = cal.get(Calendar.DAY_OF_MONTH);
                    month = cal.get(Calendar.MONTH) + 1;  // Calendar.MONTH is zero-based
                    year = cal.get(Calendar.YEAR);

                    // Check if the date is within the window from one year ago to now and not in the future
                    Calendar now = Calendar.getInstance();
                    Calendar oneYearAgo = Calendar.getInstance();
                    oneYearAgo.add(Calendar.YEAR, -1);
                    if (cal.after(now)) {
                        Toast.makeText(this, "Date cannot be in the future", Toast.LENGTH_LONG).show();
                        Log.d("debugdebug", "E: Future date");
                        return;
                    } else if (cal.before(oneYearAgo)) {
                        Toast.makeText(this, "Date cannot be more than a year ago", Toast.LENGTH_LONG).show();
                        Log.d("debugdebug", "E: Date more than one a year ago");
                        return;
                    }
                } catch (ParseException e) {
                    Log.d("debugdebug", "invalid date or time format for conversion in LoggerActivity");
                }

                // Get temperature from history and save to database when fetched
                WeatherService weatherService = new WeatherService();
                // Runnable which triggers toast for error message if fetching weather data fails
                Runnable toastError = () -> Toast.makeText(LoggerActivity.this, "Error fetching weather data from history", Toast.LENGTH_LONG).show();
                // Fetch weather now
                weatherService.fetchWeatherHistory(month, day, year, new WeatherService.WeatherServiceHistoryCallback() {
                    @SuppressLint("DefaultLocale")
                    @Override
                    public void onWeatherHistoryReceived(WeatherNow weatherNow) {
                        // get temperature
                        int temp = Math.round(weatherNow.getTemp());
                        // get date
                        long unixDate = weatherNow.getUnixDate();

                        // Save to database
                        Fit up = fitAdapterUpper.getItem(posUp);
                        Fit bot = fitAdapterBottom.getItem(posBot);
                        int upId = up.getCategoryId();
                        int botId = bot.getCategoryId();
                        dataBase.dbUp_addOne(upId, temp, unixDate);
                        dataBase.dbBot_addOne(botId, temp, unixDate);

                        int upMinTemp = up.getMinTemp();
                        int upMaxTemp = up.getMaxTemp();
                        if (temp < upMinTemp && fitAdapterUpper.getItem(posUp + 1).getMaxTemp() - fitAdapterUpper.getItem(posUp + 1).getMinTemp() > 2)
                            dataBase.dbCategories_changeTemp(upId, upId + 1, upMinTemp - dT);
                        else if (temp > upMaxTemp && fitAdapterUpper.getItem(posUp - 1).getMaxTemp() - fitAdapterUpper.getItem(posUp - 1).getMinTemp() > 2)
                            dataBase.dbCategories_changeTemp(upId - 1, upId, upMaxTemp + dT);

                        //   pos1 <   pos2 ==> tempMin1 > tempMin2 && tempMax1 > tempMax2 (pos1 = tank top && pos2 = t-shirt)
                        // ctgId1 < ctgId2 ==> tempMin1 < tempMin2 && tempMax1 < tempMax2 (ctgId1 = winter jacket && ctgId2 = sweater)

                        int botMinTemp = bot.getMinTemp();
                        int botMaxTemp = bot.getMaxTemp();
                        if (temp < botMinTemp && fitAdapterBottom.getItem(posBot + 1).getMaxTemp() - fitAdapterBottom.getItem(posBot + 1).getMinTemp() > 2)
                            dataBase.dbCategories_changeTemp(botId, botId + 1, botMinTemp - dT);
                        else if (temp > botMaxTemp && fitAdapterBottom.getItem(posBot - 1).getMaxTemp() - fitAdapterBottom.getItem(posBot - 1).getMinTemp() > 2)
                            dataBase.dbCategories_changeTemp(botId - 1, botId, botMaxTemp + dT);

                        Log.i("numbers1", "nameUp: " + up.getFitName() + ", tempMinUp = " + upMinTemp + ", tempMaxUp = " + upMaxTemp);
                        Log.i("numbers2", "nameUp: " + fitAdapterUpper.getItem(posUp + 1).getFitName() + ", tempMinUp = " + fitAdapterUpper.getItem(posUp + 1).getMinTemp() + ", tempMaxUp = " + fitAdapterUpper.getItem(posUp + 1).getMaxTemp());
                        Log.i("numbers3", "nameBot: " + bot.getFitName() + ", tempMinBot = " + botMinTemp + ", tempMaxBot = " + botMaxTemp);
                        Log.i("numbers4", "nameBot: " + fitAdapterBottom.getItem(posBot + 1).getFitName() + ", tempMinBot = " + fitAdapterBottom.getItem(posBot + 1).getMinTemp() + ", tempMaxBot = " + fitAdapterBottom.getItem(posBot + 1).getMaxTemp());

                        Log.d("SQLiteDatabase", "Added to database:" + up.getCategoryId() + ", " + bot.getCategoryId());
                        //Toast.makeText(LoggerActivity.this, "Saved", Toast.LENGTH_SHORT).show();

                        // Finish activity
                        finish();
                    }

                    @Override
                    public void onError(Exception exception) {
                        runOnUiThread(toastError);
                        Log.d("weatherService", "Error fetching weather history data");
                        exception.printStackTrace();
                    }
                });

            }
        });

        // Cancel button returns back to Main Activity
        btnLogCancel.setOnClickListener(v -> {
            finish(); // Close the current activity and go back
        });

    } /* end of onCreate */

    @Override
    protected void onDestroy() {
        // Close database
        dataBase.close();
        super.onDestroy();
    } /* end of onDestroy */
}