package com.example.weatherwear;

import androidx.annotation.NonNull;

import java.util.List;

public class FitCtgLog {
    private int categoryId;
    private List<Integer> loggedTemps;

    public FitCtgLog(int categoryId, List<Integer> loggedTemps) {
        this.categoryId = categoryId;
        this.loggedTemps = loggedTemps;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public List<Integer> getLoggedTemps() {
        return loggedTemps;
    }

    public void setLoggedTemps(List<Integer> loggedTemps) {
        this.loggedTemps = loggedTemps;
    }

    @NonNull
    @Override
    public String toString() {
        return "FitCtgLog{" +
                "categoryId=" + categoryId +
                ", loggedTemps=" + loggedTemps +
                '}';
    }
}