package com.example.weatherwear;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter_WeatherDay extends RecyclerView.Adapter<Adapter_WeatherDay.DailyWeatherViewHolder> {
    private final List<WeatherDay> weatherDataList;

    public Adapter_WeatherDay(List<WeatherDay> weatherDataList) {
        this.weatherDataList = weatherDataList;
    }

    @NonNull
    @Override
    public DailyWeatherViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cont_weather_day, parent, false);
        return new DailyWeatherViewHolder(view);
    }

    @SuppressLint("DefaultLocale")
    @Override
    public void onBindViewHolder(@NonNull DailyWeatherViewHolder holder, int position) {
        WeatherDay weatherData = weatherDataList.get(position);
        holder.date.setText(weatherData.getDate());
        holder.dayName.setText(weatherData.getDayName().substring(0,3));
        holder.temperatureHigh.setText(String.format("%.0f °C", Math.ceil(weatherData.getTemperatureHigh()) - 0.33));
        holder.temperatureLow.setText(String.format("%.0f °C", Math.floor(weatherData.getTemperatureLow()) + 0.33));
        WeatherService.loadWeatherIconImage(holder.itemView.getContext(), weatherData.getPicture(), holder.imageView);
    }

    @Override
    public int getItemCount() {
        return weatherDataList.size();
    }

    public static class DailyWeatherViewHolder extends RecyclerView.ViewHolder {
        TextView date;
        TextView dayName;
        TextView temperatureHigh;
        TextView temperatureLow;
        ImageView imageView;

        public DailyWeatherViewHolder(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.tv_date_d);
            dayName = itemView.findViewById(R.id.tv_dayName_d);
            temperatureHigh = itemView.findViewById(R.id.tv_tempH_d);
            temperatureLow = itemView.findViewById(R.id.tv_tempL_d);
            imageView = itemView.findViewById(R.id.im_weather_d);
        }
    }
}
