package com.example.weatherwear;

import androidx.annotation.NonNull;

public class WeatherDay {
    private String date;
    private String dayName;
    private float temperatureHigh;
    private float temperatureLow;
    private String picture;

    public WeatherDay(String date, String dayName, float temperatureHigh, float temperatureLow, String picture) {
        this.date = date;
        this.dayName = dayName;
        this.temperatureHigh = temperatureHigh;
        this.temperatureLow = temperatureLow;
        this.picture = picture;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDayName() {
        return dayName;
    }

    public void setDayName(String dayName) {
        this.dayName = dayName;
    }

    public float getTemperatureHigh() {
        return temperatureHigh;
    }

    public void setTemperatureHigh(float temperatureHigh) {
        this.temperatureHigh = temperatureHigh;
    }

    public float getTemperatureLow() {
        return temperatureLow;
    }

    public void setTemperatureLow(float temperatureLow) {
        this.temperatureLow = temperatureLow;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    @NonNull
    @Override
    public String toString() {
        return "WeatherDay{" +
                "date='" + date + '\'' +
                "dayName='" + dayName + '\'' +
                ", temperatureHigh=" + temperatureHigh +
                ", temperatureLow=" + temperatureLow +
                ", picture='" + picture + '\'' +
                '}';
    }
}