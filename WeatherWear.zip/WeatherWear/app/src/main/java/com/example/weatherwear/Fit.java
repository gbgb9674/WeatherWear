package com.example.weatherwear;

public class Fit {
    private int categoryId;
    private String fitName;
    private int fitImage;
    private int minTemp;
    private int maxTemp;

    public Fit(int categoryId, String fitName, int fitImage, int minTemp, int maxTemp) {
        this.categoryId = categoryId;
        this.fitName = fitName;
        this.fitImage = fitImage;
        this.minTemp = minTemp;
        this.maxTemp = maxTemp;
    }

    public int getFitImage() {
        return fitImage;
    }

    public void setFitImage(int fitImage) {
        this.fitImage = fitImage;
    }

    public String getFitName() {
        return fitName;
    }

    public void setFitName(String fitName) {
        this.fitName = fitName;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public int getMinTemp() {
        return minTemp;
    }

    public void setMinTemp(int minTemp) {
        this.minTemp = minTemp;
    }

    public int getMaxTemp() {
        return maxTemp;
    }

    public void setMaxTemp(int maxTemp) {
        this.maxTemp = maxTemp;
    }
}