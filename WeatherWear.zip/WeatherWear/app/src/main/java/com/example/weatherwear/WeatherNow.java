package com.example.weatherwear;

import androidx.annotation.NonNull;

public class WeatherNow {
    private String time;
    private String date;
    private String dayName;
    private long unixDate;
    private float temp;
    private float feels_like;
    private float temp_min;
    private float temp_max;
    private int pressure;
    private int humidity;
    private String icon;

    public WeatherNow(String time, String date, String dayName, long unixDate, float temp, float feelsLike, float tempMin, float tempMax, int pressure, int humidity, String icon) {
        this.time = time;
        this.date = date;
        this.dayName = dayName;
        this.unixDate = unixDate;
        this.temp = temp;
        feels_like = feelsLike;
        temp_min = tempMin;
        temp_max = tempMax;
        this.pressure = pressure;
        this.humidity = humidity;
        this.icon = icon;
    }

    public float getTemp() {
        return temp;
    }

    public void setTemp(float temp) {
        this.temp = temp;
    }

    public float getFeels_like() {
        return feels_like;
    }

    public void setFeels_like(float feels_like) {
        this.feels_like = feels_like;
    }

    public float getTemp_min() {
        return temp_min;
    }

    public void setTemp_min(float temp_min) {
        this.temp_min = temp_min;
    }

    public float getTemp_max() {
        return temp_max;
    }

    public void setTemp_max(float temp_max) {
        this.temp_max = temp_max;
    }

    public int getPressure() {
        return pressure;
    }

    public void setPressure(int pressure) {
        this.pressure = pressure;
    }

    public int getHumidity() {
        return humidity;
    }

    public void setHumidity(int humidity) {
        this.humidity = humidity;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @NonNull
    @Override
    public String toString() {
        return "WeatherNow{" +
                "time='" + time + '\'' +
                ", date='" + date + '\'' +
                ", temp=" + temp +
                ", feels_like=" + feels_like +
                ", temp_min=" + temp_min +
                ", temp_max=" + temp_max +
                ", pressure=" + pressure +
                ", humidity=" + humidity +
                ", icon='" + icon + '\'' +
                '}';
    }

    public long getUnixDate() {
        return unixDate;
    }

    public void setUnixDate(long unixDate) {
        this.unixDate = unixDate;
    }

    public String getDayName() {
        return dayName;
    }

    public void setDayName(String dayName) {
        this.dayName = dayName;
    }
}