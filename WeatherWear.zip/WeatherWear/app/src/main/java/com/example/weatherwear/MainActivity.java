package com.example.weatherwear;

import static com.example.weatherwear.AlarmReceiver.CHANNEL_ID;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    TextView dateNow, timeNow, tempNow, tvLoadingHourly, tvLoadingDaily;
    ImageView iconNow, upperFit, bottomFit;

    RecyclerView hourlyRecyclerView, dailyRecyclerView;

    static DataBase dataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find views by id
        // Main container for weather now
        dateNow = findViewById(R.id.tv_ct1_day);
        timeNow = findViewById(R.id.tv_ct1_time);
        tempNow = findViewById(R.id.tv_ct1_temp);
        iconNow = findViewById(R.id.im_ct1_weather_icon);
        upperFit = findViewById(R.id.im_wear_upper);
        bottomFit = findViewById(R.id.im_wear_bottom);
        // Button
        MaterialButton fbtn_log = findViewById(R.id.fbtn_log);
        //Loading texts
        tvLoadingHourly = findViewById(R.id.tv_loading_hourly);
        tvLoadingDaily = findViewById(R.id.tv_loading_daily);
        tvLoadingHourly.setVisibility(View.VISIBLE);
        tvLoadingDaily.setVisibility(View.VISIBLE);

        // Weather hourly - Recycler View
        hourlyRecyclerView = findViewById(R.id.rv_weather_hourly);
        hourlyRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        // Weather daily - Recycler View
        dailyRecyclerView = findViewById(R.id.rv_weather_daily);
        dailyRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        // Fetch weather data
        fetchAllWeatherData();

        // Log floating action button switches to Log Activity
        fbtn_log.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, LoggerActivity.class);
            startActivity(intent);
        });

        // Database - SQLite
        dataBase = new DataBase(this);

        // Save to database if not already saved
        if (dataBase.dbCategories_read().isEmpty()) {
            // Add Fit objects to the lists
            List<Fit> upperFits = new ArrayList<>();
            upperFits.add(new Fit(106, "Winter jacket", R.drawable.fit_upper6, -50, -5));
            upperFits.add(new Fit(105, "Sweater", R.drawable.fit_upper5, -5, 0));
            upperFits.add(new Fit(104, "Long sleeve shirt", R.drawable.fit_upper4, 0, 5));
            upperFits.add(new Fit(103, "Hoodie", R.drawable.fit_upper3, 5, 12));
            upperFits.add(new Fit(102, "Shirt", R.drawable.fit_upper2, 12, 20));
            upperFits.add(new Fit(101, "T-Shirt", R.drawable.fit_upper1, 20, 30));
            upperFits.add(new Fit(100, "Tank top", R.drawable.fit_upper0, 30, 75));

            List<Fit> bottomsFits = new ArrayList<>();
            bottomsFits.add(new Fit(201, "Pants", R.drawable.fit_bottom1, -50, 25));
            bottomsFits.add(new Fit(200, "Shorts", R.drawable.fit_bottom0, 25, 75));

            // Add Fit objects to the database
            for (Fit fit : upperFits) {
                dataBase.dbCategories_addOne(fit);
            }
            for (Fit fit : bottomsFits) {
                dataBase.dbCategories_addOne(fit);
            }

            Log.d("SQLiteDatabase", "Fit categories saved to database");
        }

        // Menu button
        ImageButton btnOpenMenu = findViewById(R.id.btnOpenMenu);
        btnOpenMenu.setOnClickListener(view -> {
            // Create a PopupMenu anchored to the button
            PopupMenu popupMenu = new PopupMenu(MainActivity.this, btnOpenMenu);
            popupMenu.getMenuInflater().inflate(R.menu.menu_main_page, popupMenu.getMenu());

            // Set a listener for menu item clicks
            popupMenu.setOnMenuItemClickListener(item -> {
                int itemId = item.getItemId(); // Get the item ID

                if (itemId == R.id.menu_settings) {
                    // Open settings page
                    Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                    startActivity(intent);
                } else if (itemId == R.id.menu_help) {
                    // Handle menu item 1 click
                    Log.d("mainMenu", "Legal notice");
                    // Go to info page with InfoType = 1
                    Intent intent = new Intent(MainActivity.this, InfoPageActivity.class);
                    intent.putExtra("InfoType", 1);
                    startActivity(intent);
                    return true;
                } else if (itemId == R.id.menu_legal_notice) {
                    // Handle menu item 2 click
                    Log.d("mainMenu", "item 2");
                    // Go to info page with InfoType = 2
                    Intent intent = new Intent(MainActivity.this, InfoPageActivity.class);
                    intent.putExtra("InfoType", 2);
                    startActivity(intent);
                    return true;
                }
                else if (itemId == R.id.menu_about) {
                    // Handle menu item 3 click
                    Log.d("mainMenu", "item 3");
                    // Go to info page with InfoType = 3
                    Intent intent = new Intent(MainActivity.this, InfoPageActivity.class);
                    intent.putExtra("InfoType", 3);
                    startActivity(intent);
                    return true;
                }
                // Add more menu items as needed
                return false;
            });

            // Show the PopupMenu
            popupMenu.show();
        });

        // Refresh button
        ImageButton btnRefresh = findViewById(R.id.btnRefresh);
        btnRefresh.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, R.string.text_refreshing, Toast.LENGTH_SHORT).show();
            fetchAllWeatherData();
        });

        // Notifications
        scheduleAlarm();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            // Register the channel with the system; you can't change the importance or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }


    } /* end of onCreate */

    @Override
    protected void onDestroy() {
        // Close database
        dataBase.close();
        super.onDestroy();
    } /* end of onDestroy */

    private void fetchAllWeatherData(){
        // Get weather
        WeatherService weatherService = new WeatherService();

        // Runnable which triggers toast for error message if fetching weather data fails
        Runnable toastError = () -> Toast.makeText(MainActivity.this, "Error loading weather data", Toast.LENGTH_LONG).show();

        // Fetch weather now
        weatherService.fetchWeatherNow(new WeatherService.WeatherServiceCallback() {
            @SuppressLint({"DefaultLocale", "SetTextI18n", "DiscouragedApi"})
            @Override
            public void onWeatherNowReceived(WeatherNow weatherNow) {
                // Update UI
                runOnUiThread(() -> {
                    int temp = Math.round(weatherNow.getTemp());

                    tempNow.setText(String.format("%d °C", temp));
                    dateNow.setText(weatherNow.getDayName() + ", " + weatherNow.getDate() + ".");
                    timeNow.setText("Last refresh - " + weatherNow.getTime());
                    WeatherService.loadWeatherIconImage(MainActivity.this, weatherNow.getIcon(), iconNow);

                    List<Fit> fits = dataBase.dbCategories_read();

                    for (Fit fit : fits) {
                        if (fit.getCategoryId() >= 100 && fit.getCategoryId() < 200 && temp >= fit.getMinTemp() && temp < fit.getMaxTemp())
                            upperFit.setImageResource(getResources().getIdentifier("fit_upper" + (fit.getCategoryId() - 100), "drawable", getPackageName()));
                        else if (fit.getCategoryId() >= 200 && fit.getCategoryId() < 300 && temp >= fit.getMinTemp() && temp < fit.getMaxTemp())
                            bottomFit.setImageResource(getResources().getIdentifier("fit_bottom" + (fit.getCategoryId() - 200), "drawable", getPackageName()));
                    }
                });
            }

            @Override
            public void onWeatherHourlyReceived(List<WeatherHour> weatherHours) {}

            @Override
            public void onWeatherDailyReceived(List<WeatherDay> weatherDays) {}

            @Override
            public void onError(Exception exception) {
                runOnUiThread(toastError);
                Log.d("weatherService", "Error fetching weather now data");
                exception.printStackTrace();
            }
        });

        // Fetch hourly weather
        weatherService.fetchWeatherHourly(new WeatherService.WeatherServiceCallback() {
            @Override
            public void onWeatherNowReceived(WeatherNow weatherNow) {}

            @Override
            public void onWeatherHourlyReceived(List<WeatherHour> weatherHours) {
                runOnUiThread(() -> {
                    Adapter_WeatherHour hourlyWeatherAdapter = new Adapter_WeatherHour(weatherHours);
                    hourlyRecyclerView.setAdapter(hourlyWeatherAdapter);
                    tvLoadingHourly.setVisibility(View.INVISIBLE);
                });
            }

            @Override
            public void onWeatherDailyReceived(List<WeatherDay> weatherDays) {}

            @Override
            public void onError(Exception exception) {
                runOnUiThread(toastError);
                Log.d("weatherService", "Error fetching hourly weather data");
                exception.printStackTrace();
            }
        });

        // Fetch daily weather
        weatherService.fetchWeatherDaily(new WeatherService.WeatherServiceCallback() {
            @Override
            public void onWeatherNowReceived(WeatherNow weatherNow) {}

            @Override
            public void onWeatherHourlyReceived(List<WeatherHour> weatherHours) {}

            @Override
            public void onWeatherDailyReceived(List<WeatherDay> weatherDays) {
                runOnUiThread(() -> {
                    Adapter_WeatherDay dailyWeatherAdapter = new Adapter_WeatherDay(weatherDays);
                    dailyRecyclerView.setAdapter(dailyWeatherAdapter);
                    tvLoadingDaily.setVisibility(View.INVISIBLE);
                });
            }

            @Override
            public void onError(Exception e) {
                runOnUiThread(toastError);
                Log.d("weatherService", "Error fetching daily weather data");
                e.printStackTrace();
            }
        });
    }

    // Notifications
    private void scheduleAlarm() {
        // Set the alarm
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        int notificationHour = 19;
        calendar.set(Calendar.HOUR_OF_DAY, notificationHour);
        int notificationMinutes = 0;
        calendar.set(Calendar.MINUTE, notificationMinutes);
        calendar.set(Calendar.SECOND, 0);

        // Intent to start the BroadcastReceiver
        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        // Set the alarm to wake up the device if sleeping.
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent);
    }

    private void cancelAlarm() {
        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.cancel(pendingIntent);
        pendingIntent.cancel(); // Also cancel the PendingIntent
    }
}