package com.example.weatherwear;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.widget.ImageView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Response;
import okhttp3.Request;
import okhttp3.Call;
import okhttp3.Callback;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;


public class WeatherService {

    private final String apiKey = "5c256a734be98f5bd29e00a70211d036";

    // Callback for returning data to main when it's ready
    public interface WeatherServiceCallback {
        void onWeatherNowReceived(WeatherNow weatherNow);
        void onWeatherHourlyReceived(List<WeatherHour> weatherHours);
        void onWeatherDailyReceived(List<WeatherDay> weatherDays);
        void onError(Exception e);
    }

    public interface WeatherServiceHistoryCallback {
        void onWeatherHistoryReceived(WeatherNow weatherNow);
        void onError(Exception e);
    }

    public void fetchWeatherNow(WeatherServiceCallback callback) {
        // String city = "Ljubljana";
        //String url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey;
        String url = "https://api.openweathermap.org/data/2.5/weather?lat=44.34&lon=10.99&appid=" + apiKey;

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        Log.d("weatherService", "Fetching weather now");

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException exception) {
                Log.d("weatherService", "Failure fetching");
                exception.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String responseData = response.body().string();

                    WeatherNow weatherNow = new WeatherNow("HH:mm", "MM.dd", "", 0, 0, 0, 0, 0, 0, 0, "");

                    try {
                        // Create a JSONObject from the response data
                        JSONObject jsonObject = new JSONObject(responseData);

                        // Get timestamp
                        long timestamp = jsonObject.getInt("dt");
                        String date = getDateString(timestamp);
                        String time = getTimeString(timestamp);
                        String dayName = getDayName(timestamp);

                        Log.d("debugdebug", "dt from service in unix: " + timestamp);

                        // Get the "weather" JSONArray
                        JSONArray weatherArray = jsonObject.getJSONArray("weather");
                        // Get the first object from the weather array
                        JSONObject weatherObject = weatherArray.getJSONObject(0);
                        // Extract the icon
                        String icon = weatherObject.getString("icon");

                        // Get the "main" JSONObject
                        JSONObject mainObject = jsonObject.getJSONObject("main");

                        // Extract the fields, convert temperatures from Kelvin to Celsius
                        float temp = (float) mainObject.getDouble("temp") - 273;
                        float feels_like = (float) mainObject.getDouble("feels_like") - 273;
                        float temp_min = (float) mainObject.getDouble("temp_min") - 273;
                        float temp_max = (float) mainObject.getDouble("temp_max") - 273;
                        int pressure = mainObject.getInt("pressure");
                        int humidity = mainObject.getInt("humidity");

                        // Save to object
                        weatherNow.setDate(date);
                        weatherNow.setTime(time);
                        weatherNow.setDayName(dayName);
                        weatherNow.setTemp(temp);
                        weatherNow.setFeels_like(feels_like);
                        weatherNow.setTemp_max(temp_max);
                        weatherNow.setTemp_min(temp_min);
                        weatherNow.setPressure(pressure);
                        weatherNow.setHumidity(humidity);
                        weatherNow.setIcon(icon);

                        Log.d("weatherService", weatherNow.toString());

                        // return data in a callback
                        callback.onWeatherNowReceived(weatherNow);

                    } catch (JSONException exception) {
                        callback.onError(exception);
                        // exception.printStackTrace();
                    }
                }
            }
        });
    } /* end of fetchWeatherNow */

    public void fetchWeatherHistory(int month, int day, int year, WeatherServiceHistoryCallback callback) {
        // String city = "Ljubljana";
        String url = "https://history.openweathermap.org/data/2.5/aggregated/day?lat=44.34&lon=10.99&month=" + month + "&day=" + day + "&appid=" + apiKey;

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        Log.d("weatherService", "Fetching weather history");

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException exception) {
                Log.d("weatherService", "Failure fetching");
                exception.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String responseData = response.body().string();

                    WeatherNow weatherNow = new WeatherNow("HH:mm", "MM.dd", "", 0, 0, 0, 0, 0, 0, 0, "");

                    try {
                        // Create a JSONObject from the response data
                        JSONObject jsonObject = new JSONObject(responseData);

                        // Get the "main" JSONObject
                        JSONObject resultObject = jsonObject.getJSONObject("result");
                        // Get the "main" JSONObject
                        JSONObject mainObject = resultObject.getJSONObject("temp");

                        // Extract the fields, convert temperatures from Kelvin to Celsius
                        float temp = (float) mainObject.getDouble("mean") - 273;
                        float temp_min = (float) mainObject.getDouble("record_min") - 273;
                        float temp_max = (float) mainObject.getDouble("record_max") - 273;

                        //Get unix date
                        long unixDate = getUnixTimestamp(month, day, year);

                        // Save to object
                        weatherNow.setUnixDate(unixDate);
                        weatherNow.setTemp(temp);
                        weatherNow.setTemp_max(temp_max);
                        weatherNow.setTemp_min(temp_min);

                        Log.d("weatherService", weatherNow.toString());

                        // return data in a callback
                        callback.onWeatherHistoryReceived(weatherNow);

                    } catch (JSONException exception) {
                        callback.onError(exception);
                        // exception.printStackTrace();
                    }
                }
            }
        });
    } /* end of fetchWeatherHistory */


    public void fetchWeatherHourly(WeatherServiceCallback callback) {
        //String city = "Ljubljana";
        int numOfHours = 24; //A number of timestamps to request (max 96)
        // TODO: get lon and lat from city name
        String url = "https://pro.openweathermap.org/data/2.5/forecast/hourly?lat=44.34&lon=10.99&cnt="+ numOfHours +"&appid=" + apiKey;
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        Log.d("weatherService", "Fetching hourly weather");

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException exception) {
                Log.d("weatherService", "Failure fetching");
                exception.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String responseData = response.body().string();
                    try {
                        // Create a JSONObject from the response data
                        JSONObject jsonObject = new JSONObject(responseData);

                        // Get the "list" JSONArray
                        JSONArray listArray = jsonObject.getJSONArray("list");

                        // Create a list to hold WeatherHour objects
                        List<WeatherHour> weatherHours = new ArrayList<>();

                        // Loop through each object in the list array
                        for (int i = 0; i < listArray.length(); i++) {
                            JSONObject dayObject = listArray.getJSONObject(i);

                            // Get the timestamp of data
                            long timestamp = dayObject.getInt("dt");
                            String time = getTimeString(timestamp);

                            // Get the "main" JSONObject
                            JSONObject mainObject = dayObject.getJSONObject("main");
                            // Extract the temperature
                            float temp = (float) mainObject.getDouble("temp") - 273;

                            // Get the "weather" JSONArray
                            JSONArray weatherArray = dayObject.getJSONArray("weather");
                            // Get the first object from the weather array
                            JSONObject weatherObject = weatherArray.getJSONObject(0);
                            // Extract the icon
                            String icon = weatherObject.getString("icon");

                            // Create a WeatherHour object and add it to the list
                            WeatherHour weatherHour = new WeatherHour(time, temp, icon);
                            weatherHours.add(weatherHour);
                        }

                        Log.d("weatherService", weatherHours.toString());

                        callback.onWeatherHourlyReceived(weatherHours);


                    } catch (JSONException exception) {
                        callback.onError(exception);
                    }
                }
            }
        });
    } /* end of fetchWeatherHourly */

    public void fetchWeatherDaily(WeatherServiceCallback callback){
        // String city = "Ljubljana";
        int numOfDays = 10; //A number of days to request (max 16)
        // TODO: get longitude and latitude from city name
        String url = "https://api.openweathermap.org/data/2.5/forecast/daily?lat=44.34&lon=10.99&cnt=" + numOfDays + "&appid=" + apiKey;

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        Log.d("weatherService", "Fetching daily weather");

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException exception) {
                Log.d("weatherService", "Failure fetching");
                exception.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    String responseData = response.body().string();

                    try {
                        // Create a JSONObject from the response data
                        JSONObject jsonObject = new JSONObject(responseData);

                        // Get the "list" JSONArray
                        JSONArray listArray = jsonObject.getJSONArray("list");

                        // Create a list to hold WeatherHour objects
                        List<WeatherDay> weatherDays = new ArrayList<>();

                        // Loop through each object in the list array, start with index 1 to exclude
                        // today's weather
                        for (int i = 1; i < listArray.length(); i++) {
                            JSONObject dayObject = listArray.getJSONObject(i);

                            // Get the timestamp of data
                            long timestamp = dayObject.getInt("dt");
                            String date = getDateString(timestamp);
                            String dayName = getDayName(timestamp);

                            // Get the "temp" JSONObject
                            JSONObject mainObject = dayObject.getJSONObject("temp");
                            // Extract the temperatures
                            float tempMax = (float) mainObject.getDouble("day") - 273;
                            float tempMin = (float) mainObject.getDouble("min") - 273;

                            // Get the "weather" JSONArray
                            JSONArray weatherArray = dayObject.getJSONArray("weather");
                            // Get the first object from the weather array
                            JSONObject weatherObject = weatherArray.getJSONObject(0);
                            // Extract the icon
                            String icon = weatherObject.getString("icon");

                            // Create a WeatherHour object and add it to the list
                            WeatherDay weatherDay = new WeatherDay(date, dayName, tempMax, tempMin, icon);
                            weatherDays.add(weatherDay);
                        }

                        Log.d("weatherService", weatherDays.toString());

                        callback.onWeatherDailyReceived(weatherDays);
                    } catch (JSONException e) {
                        callback.onError(e);
                    }
                }
            }
        });
    } /* end of fetchWeatherDaily */

    // Weather icon image loader
    public static void loadWeatherIconImage(Context context, String iconCode, ImageView imageView) {
        if("01d".equals(iconCode)) {
            imageView.setImageResource(R.drawable.wi_01d);
        } else if("01n".equals(iconCode)){
            imageView.setImageResource(R.drawable.wi_01n);
        } else{
            String url = "https://openweathermap.org/img/wn/" + iconCode + "@2x.png";
            Glide.with(context)
                    .load(url)
                    .into(imageView);
        }
    }

    public static String getDateString(long timestamp) {
        Date date = new Date(timestamp * 1000L);
        @SuppressLint("SimpleDateFormat") SimpleDateFormat dateFormatter = new SimpleDateFormat("dd.MM");
        dateFormatter.setTimeZone(TimeZone.getDefault());
        return dateFormatter.format(date);
    }

    public static String getDateStringWithDay(long timestamp) {
        Date date = new Date(timestamp * 1000L);
        // Format for day of the week
        SimpleDateFormat dayFormatter = new SimpleDateFormat("EEEE", Locale.getDefault());
        dayFormatter.setTimeZone(TimeZone.getDefault());
        String dayOfWeek = dayFormatter.format(date);
        // Format for date
        SimpleDateFormat dateFormatter = new SimpleDateFormat("d.M", Locale.getDefault());
        dateFormatter.setTimeZone(TimeZone.getDefault());
        String dateOfMonth = dateFormatter.format(date);

        return dayOfWeek + ", " + dateOfMonth;
    }

    public static String getDayName(long timestamp)
    {
        Date date = new Date(timestamp * 1000L);
        // Format for day of the week
        SimpleDateFormat dayFormatter = new SimpleDateFormat("EEEE", Locale.getDefault());
        dayFormatter.setTimeZone(TimeZone.getDefault());
        return dayFormatter.format(date);
    }

    public static String getTimeString(long timestamp) {
        Date date = new Date(timestamp * 1000L);
        @SuppressLint("SimpleDateFormat") SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm");
        timeFormatter.setTimeZone(TimeZone.getDefault());
        return timeFormatter.format(date);
    }

    public static long getUnixTimestamp(int month, int day, int year) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, day); // Month is 0-based in Calendar

        // Convert to Unix timestamp (in milliseconds)
        return calendar.getTimeInMillis() / 1000;

        /*Log.d("debugdebug", "Input- m:" + month + " d:" + day + " y:" + year);
        Log.d("debugdebug", "Output:" + unixTimestamp);*/
    }

}