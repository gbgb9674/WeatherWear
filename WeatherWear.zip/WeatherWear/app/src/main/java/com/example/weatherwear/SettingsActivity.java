package com.example.weatherwear;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        ImageButton backBtn = findViewById(R.id.btn_settings_back);
        Button deleteDbBtn = findViewById(R.id.btn_delete_db);

        // Delete button triggers popup window for conformation of database wipe
        deleteDbBtn.setOnClickListener(v -> {
            // Popup for conformation
            AlertDialog.Builder builder = new AlertDialog.Builder(SettingsActivity.this);
            builder.setCancelable(true);
            builder.setTitle("User data wipe");
            builder.setMessage("Are you sure you want to delete all logged user data?");
            builder.setPositiveButton("Confirm",
                    (dialog, which) -> {
                        // Delete user data from database
                        DataBase dataBase = new DataBase(SettingsActivity.this);
                        dataBase.db_deleteUserLogs();
                        Toast.makeText(SettingsActivity.this, "User data deleted", Toast.LENGTH_LONG).show();
                    });
            builder.setNegativeButton("Cancel",
                    (dialog, which) -> {
                        // Do nothing
                    });

            AlertDialog dialog = builder.create();
            dialog.show();
        });

        // Back button returns to MainActivity
        backBtn.setOnClickListener(v -> finish());
    }
}