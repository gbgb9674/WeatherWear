package com.example.weatherwear;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class InfoPageActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_page);

        // Intent
        Intent receivedIntent = getIntent();
        int infoPageType = receivedIntent.getIntExtra("InfoType", 0);

        // Views
        TextView title = findViewById(R.id.tv_title_info);
        TextView text = findViewById(R.id.tv_info);
        ImageButton backBtn = findViewById(R.id.btn_info_back);

        if (infoPageType == 1) {
            title.setText(R.string.info_titile_help);
            text.setText(R.string.info_content_help);
        }
        else if (infoPageType == 2) {
            title.setText(R.string.info_title_legal);
            text.setText(getString(R.string.info_content_flaticon) + "\n\n" + getString(R.string.info_content_openweather));
        }
        else if (infoPageType == 3) {
            title.setText(R.string.info_title_about);
            text.setText(R.string.info_content_about);
        }
        else {
            Toast.makeText(this, "Invalid info page", Toast.LENGTH_LONG).show();
        }

        // Back button returns back to Main Activity
        backBtn.setOnClickListener(v -> finish());
    }
}